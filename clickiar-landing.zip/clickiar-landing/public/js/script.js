// Puedes agregar funcionalidad JavaScript adicional aquí si lo necesitas
